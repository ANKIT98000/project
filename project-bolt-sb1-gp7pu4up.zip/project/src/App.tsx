import React, { useState, useEffect } from 'react';
import { Bus, MapPin, Clock, Users, CreditCard, Mail, Phone, User } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { motion, AnimatePresence } from 'framer-motion';
import useSound from 'use-sound';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icons in React-Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface Stop {
  name: string;
  location: [number, number];
  timeFromStart: number;
}

interface BusRoute {
  id: number;
  name: string;
  from: string;
  to: string;
  departureTime: string;
  duration: string;
  totalSeats: number;
  availableSeats: number;
  price: number;
  stops: Stop[];
  currentLocation?: [number, number];
}

const busRoutes: BusRoute[] = [
  {
    id: 1,
    name: "Pink Express",
    from: "Sindhi Camp",
    to: "Hawa Mahal",
    departureTime: "07:00 AM",
    duration: "25m",
    totalSeats: 40,
    availableSeats: 15,
    price: 20,
    stops: [
      { name: "Sindhi Camp", location: [26.9196, 75.7878], timeFromStart: 0 },
      { name: "Ajmeri Gate", location: [26.9187, 75.8144], timeFromStart: 10 },
      { name: "Hawa Mahal", location: [26.9239, 75.8267], timeFromStart: 25 }
    ]
  },
  {
    id: 2,
    name: "Heritage Line",
    from: "Jal Mahal",
    to: "City Palace",
    departureTime: "08:30 AM",
    duration: "35m",
    totalSeats: 35,
    availableSeats: 20,
    price: 25,
    stops: [
      { name: "Jal Mahal", location: [26.9537, 75.8463], timeFromStart: 0 },
      { name: "Amber Fort", location: [26.9855, 75.8513], timeFromStart: 15 },
      { name: "City Palace", location: [26.9257, 75.8236], timeFromStart: 35 }
    ]
  },
  {
    id: 3,
    name: "Market Special",
    from: "Bapu Bazaar",
    to: "World Trade Park",
    departureTime: "09:00 AM",
    duration: "30m",
    totalSeats: 45,
    availableSeats: 25,
    price: 15,
    stops: [
      { name: "Bapu Bazaar", location: [26.9161, 75.8204], timeFromStart: 0 },
      { name: "Nehru Bazaar", location: [26.9172, 75.8235], timeFromStart: 10 },
      { name: "World Trade Park", location: [26.8541, 75.8089], timeFromStart: 30 }
    ]
  },
  {
    id: 4,
    name: "Science Express",
    from: "Birla Temple",
    to: "Science Park",
    departureTime: "10:00 AM",
    duration: "20m",
    totalSeats: 30,
    availableSeats: 18,
    price: 18,
    stops: [
      { name: "Birla Temple", location: [26.8921, 75.8144], timeFromStart: 0 },
      { name: "Science Park", location: [26.8928, 75.8090], timeFromStart: 20 }
    ]
  },
  {
    id: 5,
    name: "Airport Link",
    from: "Airport Terminal",
    to: "Railway Station",
    departureTime: "06:30 AM",
    duration: "45m",
    totalSeats: 50,
    availableSeats: 30,
    price: 40,
    stops: [
      { name: "Airport Terminal", location: [26.8242, 75.8097], timeFromStart: 0 },
      { name: "Durgapura", location: [26.8614, 75.7914], timeFromStart: 20 },
      { name: "Railway Station", location: [26.9190, 75.7890], timeFromStart: 45 }
    ]
  },
  {
    id: 6,
    name: "College Route",
    from: "Maharani College",
    to: "University",
    departureTime: "08:00 AM",
    duration: "25m",
    totalSeats: 42,
    availableSeats: 22,
    price: 15,
    stops: [
      { name: "Maharani College", location: [26.9116, 75.8174], timeFromStart: 0 },
      { name: "University", location: [26.8476, 75.8072], timeFromStart: 25 }
    ]
  },
  {
    id: 7,
    name: "Garden Special",
    from: "Central Park",
    to: "Ram Niwas Garden",
    departureTime: "09:30 AM",
    duration: "15m",
    totalSeats: 35,
    availableSeats: 15,
    price: 12,
    stops: [
      { name: "Central Park", location: [26.9018, 75.7873], timeFromStart: 0 },
      { name: "Ram Niwas Garden", location: [26.9115, 75.8194], timeFromStart: 15 }
    ]
  },
  {
    id: 8,
    name: "Shopping Express",
    from: "MI Road",
    to: "Pink Square Mall",
    departureTime: "11:00 AM",
    duration: "30m",
    totalSeats: 40,
    availableSeats: 25,
    price: 20,
    stops: [
      { name: "MI Road", location: [26.9115, 75.7873], timeFromStart: 0 },
      { name: "Crystal Court", location: [26.9012, 75.7874], timeFromStart: 15 },
      { name: "Pink Square Mall", location: [26.8539, 75.8089], timeFromStart: 30 }
    ]
  },
  {
    id: 9,
    name: "Tourist Circuit",
    from: "Albert Hall",
    to: "Nahargarh Fort",
    departureTime: "08:45 AM",
    duration: "40m",
    totalSeats: 45,
    availableSeats: 28,
    price: 35,
    stops: [
      { name: "Albert Hall", location: [26.9115, 75.8194], timeFromStart: 0 },
      { name: "Jantar Mantar", location: [26.9247, 75.8243], timeFromStart: 20 },
      { name: "Nahargarh Fort", location: [26.9373, 75.8143], timeFromStart: 40 }
    ]
  },
  {
    id: 10,
    name: "Night Rider",
    from: "Gaurav Tower",
    to: "Jawahar Circle",
    departureTime: "07:00 PM",
    duration: "35m",
    totalSeats: 38,
    availableSeats: 38,
    price: 25,
    stops: [
      { name: "Gaurav Tower", location: [26.8539, 75.8089], timeFromStart: 0 },
      { name: "Apex Circle", location: [26.8614, 75.8089], timeFromStart: 15 },
      { name: "Jawahar Circle", location: [26.8242, 75.8097], timeFromStart: 35 }
    ]
  }
];

interface BookingFormData {
  name: string;
  email: string;
  phone: string;
  passengers: number;
}

function App() {
  const [selectedRoute, setSelectedRoute] = useState<BusRoute | null>(null);
  const [routes, setRoutes] = useState(busRoutes);
  const [showBooking, setShowBooking] = useState(false);
  const [bookingData, setBookingData] = useState<BookingFormData>({
    name: '',
    email: '',
    phone: '',
    passengers: 1
  });

  // Sound effects
  const [playSelect] = useSound('https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3', { volume: 0.5 });
  const [playBook] = useSound('https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3', { volume: 0.5 });

  // Simulate bus movement and seat updates
  useEffect(() => {
    if (!selectedRoute) return;

    const updateInterval = setInterval(() => {
      setRoutes(prevRoutes => {
        return prevRoutes.map(route => {
          if (route.id === selectedRoute.id) {
            const newAvailableSeats = Math.max(
              0,
              route.availableSeats + Math.floor(Math.random() * 3) - 1
            );

            const now = new Date();
            const departure = new Date(
              now.toDateString() + ' ' + route.departureTime
            );
            const minutesSinceDeparture = 
              (now.getTime() - departure.getTime()) / (1000 * 60);

            let currentLocation = route.stops[0].location;
            for (let i = 0; i < route.stops.length - 1; i++) {
              const currentStop = route.stops[i];
              const nextStop = route.stops[i + 1];
              
              if (minutesSinceDeparture >= currentStop.timeFromStart &&
                  minutesSinceDeparture <= nextStop.timeFromStart) {
                const progress = (minutesSinceDeparture - currentStop.timeFromStart) /
                               (nextStop.timeFromStart - currentStop.timeFromStart);
                
                currentLocation = [
                  currentStop.location[0] + (nextStop.location[0] - currentStop.location[0]) * progress,
                  currentStop.location[1] + (nextStop.location[1] - currentStop.location[1]) * progress
                ];
                break;
              }
            }

            return {
              ...route,
              availableSeats: newAvailableSeats,
              currentLocation: currentLocation as [number, number]
            };
          }
          return route;
        });
      });
    }, 5000);

    return () => clearInterval(updateInterval);
  }, [selectedRoute]);

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playBook();
    alert(`Booking confirmed!\n\nDetails:\nName: ${bookingData.name}\nRoute: ${selectedRoute?.name}\nPassengers: ${bookingData.passengers}\nTotal Amount: ₹${(selectedRoute?.price || 0) * bookingData.passengers}`);
    setShowBooking(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-pink-600 text-white py-6">
        <div className="container mx-auto px-4">
          <motion.div 
            className="flex items-center space-x-2"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Bus className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Jaipur City Bus Explorer</h1>
          </motion.div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <motion.h2 
              className="text-xl font-semibold mb-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              Available City Routes
            </motion.h2>
            {routes.map((route, index) => (
              <motion.div
                key={route.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-lg shadow-md p-6 cursor-pointer transition-all hover:shadow-lg ${
                  selectedRoute?.id === route.id ? 'ring-2 ring-pink-500' : ''
                }`}
                onClick={() => {
                  setSelectedRoute(route);
                  playSelect();
                }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold text-pink-600">{route.name}</h3>
                    <div className="flex items-center mt-2 text-gray-600">
                      <MapPin className="w-4 h-4 mr-1" />
                      <span>{route.from} → {route.to}</span>
                    </div>
                    <div className="flex items-center mt-2 text-gray-600">
                      <Clock className="w-4 h-4 mr-1" />
                      <span>{route.departureTime} ({route.duration})</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-pink-600">₹{route.price}</p>
                    <div className="flex items-center mt-2 text-gray-600">
                      <Users className="w-4 h-4 mr-1" />
                      <span>{route.availableSeats} seats left</span>
                    </div>
                  </div>
                </div>
                
                <div className="mt-4">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <motion.div
                      className={`h-2 rounded-full ${
                        route.availableSeats < 10 ? 'bg-red-500' : 'bg-green-500'
                      }`}
                      initial={{ width: 0 }}
                      animate={{ width: `${(route.availableSeats / route.totalSeats) * 100}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="space-y-4">
            <AnimatePresence mode="wait">
              {showBooking && selectedRoute ? (
                <motion.div
                  key="booking"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="bg-white rounded-lg shadow-md p-6"
                >
                  <h2 className="text-2xl font-bold text-pink-600 mb-6">Book Your Ticket</h2>
                  <form onSubmit={handleBookingSubmit} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Name</label>
                      <div className="mt-1 relative">
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                        <input
                          type="text"
                          required
                          className="pl-10 w-full rounded-lg border-gray-300 focus:ring-pink-500 focus:border-pink-500"
                          value={bookingData.name}
                          onChange={(e) => setBookingData({...bookingData, name: e.target.value})}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Email</label>
                      <div className="mt-1 relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                        <input
                          type="email"
                          required
                          className="pl-10 w-full rounded-lg border-gray-300 focus:ring-pink-500 focus:border-pink-500"
                          value={bookingData.email}
                          onChange={(e) => setBookingData({...bookingData, email: e.target.value})}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Phone</label>
                      <div className="mt-1 relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                        <input
                          type="tel"
                          required
                          className="pl-10 w-full rounded-lg border-gray-300 focus:ring-pink-500 focus:border-pink-500"
                          value={bookingData.phone}
                          onChange={(e) => setBookingData({...bookingData, phone: e.target.value})}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Number of Passengers</label>
                      <input
                        type="number"
                        min="1"
                        max={selectedRoute.availableSeats}
                        required
                        className="mt-1 w-full rounded-lg border-gray-300 focus:ring-pink-500 focus:border-pink-500"
                        value={bookingData.passengers}
                        onChange={(e) => setBookingData({...bookingData, passengers: parseInt(e.target.value)})}
                      />
                    </div>
                    <div className="pt-4">
                      <p className="text-lg font-semibold">Total Amount: ₹{selectedRoute.price * bookingData.passengers}</p>
                    </div>
                    <div className="flex space-x-4">
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        type="submit"
                        className="flex-1 bg-pink-600 text-white py-2 px-4 rounded-lg hover:bg-pink-700 transition-colors"
                      >
                        Confirm Booking
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        type="button"
                        onClick={() => setShowBooking(false)}
                        className="flex-1 bg-gray-200 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors"
                      >
                        Cancel
                      </motion.button>
                    </div>
                  </form>
                </motion.div>
              ) : selectedRoute ? (
                <motion.div
                  key="details"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <h2 className="text-2xl font-bold text-pink-600 mb-4">Route Details</h2>
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-semibold">{selectedRoute.name}</h3>
                        <p className="text-gray-600">Route #{selectedRoute.id}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="font-semibold">From</p>
                          <p className="text-gray-600">{selectedRoute.from}</p>
                        </div>
                        <div>
                          <p className="font-semibold">To</p>
                          <p className="text-gray-600">{selectedRoute.to}</p>
                        </div>
                        <div>
                          <p className="font-semibold">Departure</p>
                          <p className="text-gray-600">{selectedRoute.departureTime}</p>
                        </div>
                        <div>
                          <p className="font-semibold">Duration</p>
                          <p className="text-gray-600">{selectedRoute.duration}</p>
                        </div>
                      </div>
                      <div className="mt-6">
                        <p className="font-semibold">Seat Availability</p>
                        <p className="text-gray-600">
                          {selectedRoute.availableSeats} seats available out of {selectedRoute.totalSeats}
                        </p>
                      </div>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="w-full mt-6 bg-pink-600 text-white py-2 px-4 rounded-lg hover:bg-pink-700 transition-colors"
                        onClick={() => {
                          playBook();
                          setShowBooking(true);
                        }}
                      >
                        Book Now - ₹{selectedRoute.price}
                      </motion.button>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-md p-6 mt-4">
                    <h3 className="text-lg font-semibold mb-4">Live Location</h3>
                    <div className="h-[400px] rounded-lg overflow-hidden">
                      <MapContainer
                        center={selectedRoute.stops[0].location}
                        zoom={13}
                        style={{ height: '100%', width: '100%' }}
                      >
                        <TileLayer
                          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        />
                        {selectedRoute.stops.map((stop, index) => (
                          <Marker key={index} position={stop.location}>
                            <Popup>{stop.name}</Popup>
                          </Marker>
                        ))}
                        {selectedRoute.currentLocation && (
                          <Marker
                            position={selectedRoute.currentLocation}
                            icon={L.divIcon({
                              className: 'bg-pink-600 rounded-full w-4 h-4',
                              iconSize: [16, 16]
                            })}
                          >
                            <Popup>Current Location</Popup>
                          </Marker>
                        )}
                      </MapContainer>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="bg-white rounded-lg shadow-md p-6 text-center text-gray-500"
                >
                  <Bus className="w-16 h-16 mx-auto mb-4" />
                  <p>Select a route to view details and live location</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;